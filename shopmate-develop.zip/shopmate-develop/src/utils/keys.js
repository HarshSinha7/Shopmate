/**
 * stripe api key
 *
 * @returns {string} stripe api key
 */
export const stripeKey = "pk_test_vNzwtQuyovYllXMtYOmm3s6I00Vx2yBbR4";
