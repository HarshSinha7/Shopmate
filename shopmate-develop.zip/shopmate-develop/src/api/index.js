export default "https://backendapi.turing.com";
export const stripeAPI = "https://api.stripe.com/v1/tokens";
